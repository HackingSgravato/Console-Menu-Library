﻿using System;
using Console = Colorful.Console;
using System.Drawing;
// example:
// in main function I wrote:
// Menu.Write(35, 25, logo, Color.Red, 4, voices_names, Color.DarkBlue);   
// Menu.Choosevoices(Color.Cyan, Color.DarkCyan, String.Empty);

// get ascii art here:
// https://onlineasciitools.com/convert-text-to-ascii-art

// example custom_choosePhrase
// string custom_choosePhrase = "\n<< choose a voice <<\n>> ";

// get the choosen voice example:
// uint u = Menu.Choosevoices(Color.Cyan, Color.DarkCyan, String.Empty);
// Console.WriteLine("choosen voice: " + u);

// method you can use:
// Menu.Write()
// Menu.Choosevoice()
// Menu.Clear()

// list template:
// example. [1] first voice
// string list_template = "brackets"
//
// example. 1. first voice 
// string list_template = "numberswithdot"
//
// example. 1) first voice
// string list_template = "numberswithroundbracket"
//
// example. [+] voice sum
// string list_template = "symbolwithname"

// attention:
// if you use symbolwithname
// to get the choosen symbol you must do this:
// Convert.ToChar(Choosevoice(bla, bla));

// example multi char:
// string[] voices_names = {"prima voce", "seconda voce", "terza voce", "quarta voce"};
// string[] symbols = { "+", "-", "*", "/" };
// Menu.Write(35, 25, logo, Color.Red, 4, voices_names, Color.DarkBlue, "symbolwithname", symbols, Color.GreenYellow, true);
// if (Convert.ToChar(Menu.Choosevoice(Color.Cyan, Color.DarkCyan, String.Empty, true)) == '+')
//    Console.Write("bella pe te");
//
// another example:
// Menu.Write(35, 25, logo, Color.Red, 5, voices_names, Color.DarkBlue, "numberswithroundbracket", Array.Empty<string>(), Color.GreenYellow, false);
//
// another example:
// string[] voices_names = {"prima voce", "seconda voce", "terza voce", "quarta voce", "quinta voce"};
// string[] symbols = { "+" };
// Menu.Write(35, 25, logo, Color.Red, 5, voices_names, Color.DarkBlue, "symbolwithname", symbols, Color.GreenYellow, false);

namespace Console_Menu
{
    internal class Menu
    {
        static string Logo(string logo_string, Color logo_color)
        {
            Console.ForegroundColor = logo_color;
            /* example
            string logo = @"      __  __                  
     |  \/  |                 
     | \  / | ___ _ __  _   _ 
     | |\/| |/ _ | '_ \| | | |
     | |  | |  __| | | | |_| |
     |_|  |_|\___|_| |_|\__,_|
                              
                              ";
            */
            return logo_string;
        }
        static void Size(int width, int height)
        {
            // width must be < 120
            // height must be < 30
            Console.SetWindowSize(width, height);
        }
        static void voices(int voices_number, string[] voices_names, Color voices_color, string list_template, string[] symbol_s, Color symbol_color, bool multiple_symbol)
        {
            Console.ForegroundColor = voices_color;
            if (list_template == "brackets")
            {
                for (int i = 0; i < voices_number; i++)
                {
                    Console.WriteLine($"[{i + 1}] {voices_names[i]}");
                }
            }
            else if (list_template == "numberswithdot")
            {
                for (int i = 0; i < voices_number; i++)
                {
                    Console.WriteLine($"{i + 1}. {voices_names[i]}");
                }
            }
            else if (list_template == "numberswithroundbracket")
            {
                for (int i = 0; i < voices_number; i++)
                {
                    Console.WriteLine($"{i + 1}) {voices_names[i]}");
                }
            }
            else if (list_template == "symbolwithname")
            {
                if (multiple_symbol)
                {
                    for (int i = 0; i < symbol_s.Length; i++)
                    {
                        Console.ForegroundColor = voices_color;
                        Console.Write($"[");
                        Console.ForegroundColor = symbol_color;
                        Console.Write($"{symbol_s[i]}");
                        Console.ForegroundColor = voices_color;
                        Console.Write($"] { voices_names[i]}\n");
                    }
                }
                else
                {
                    for (int i = 0; i < voices_number; i++)
                    {
                        Console.ForegroundColor = voices_color;
                        Console.Write($"[");
                        Console.ForegroundColor = symbol_color;
                        Console.Write($"{symbol_s[0]}");
                        Console.ForegroundColor = voices_color;
                        Console.Write($"] { voices_names[i]}\n");
                    }
                }
            }
            else
            {
                Console.WriteLine("template doesn't find");
                Environment.Exit(0);
            }
        }
        public static void Write(int width, int height, string logo_string, Color logo_color, int voices_number, string[] voices_names, Color voices_color, string list_template, string[] symbol_s, Color symbol_s_color, bool multiple_symbol)
        {
            choosen_symbol = symbol_s;
            n_voices = voices_number;
            Size(width, height);
            Console.WriteLine(Logo(logo_string, logo_color));
            Console.ForegroundColor = Color.White;
            voices(voices_number, voices_names, voices_color, list_template, symbol_s, symbol_s_color, multiple_symbol);
            Console.ForegroundColor = Color.White;
        }
        static string[] choosen_symbol = {""} ;
        static int n_voices = 0;
        public static uint Choosevoice(Color choosePhrase_color, Color userinput_color, string custom_choosePhrase, bool multiple_symbol)
        {
            uint choosen_voice = 0;
            bool found_char = false;

            Console.ForegroundColor = choosePhrase_color;
            if (custom_choosePhrase != String.Empty)
                Console.Write(custom_choosePhrase);
            else
                Console.Write("\n<< choose a voice >>\n>> ");
            Console.ForegroundColor = userinput_color;
            
            if (choosen_symbol != Array.Empty<string>())
            {
                var userinput = Console.ReadLine();
                if (multiple_symbol)
                {
                    try
                    {
                        char c = Convert.ToChar(userinput);
                        foreach (string s in choosen_symbol)
                        {
                            if (userinput == s)
                            {
                                found_char = true;
                            }
                        }
                        if (found_char)
                        {
                            return Convert.ToUInt32(c);
                        }
                        else
                        {
                            Console.WriteLine("char not found");
                            Environment.Exit(1);
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.ToString());
                        Environment.Exit(1);
                    }
                }
                else
                {
                    try
                    {
                        char c = Convert.ToChar(userinput);
                        if (Convert.ToString(c) == choosen_symbol[0])
                            return Convert.ToUInt32(c);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.ToString());
                        Environment.Exit(1);
                    }
                }
            }
            else
            {
                try
                {
                    choosen_voice = Convert.ToUInt32(Console.ReadLine());
                    if (choosen_voice > n_voices || choosen_voice == 0)
                    {
                        Console.WriteLine("valore errato");
                        Environment.Exit(0);
                    }
                    return choosen_voice;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    Environment.Exit(0);
                }
            }
            return 0;
        }
        public static void Clear()
        {
            Console.Clear();
        }

    }
}
