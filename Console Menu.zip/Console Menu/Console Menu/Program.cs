﻿using System;
using System.Threading;
using System.Drawing;

namespace Console_Menu
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string logo = @"      __  __                  
     |  \/  |                 
     | \  / | ___ _ __  _   _ 
     | |\/| |/ _ | '_ \| | | |
     | |  | |  __| | | | |_| |
     |_|  |_|\___|_| |_|\__,_|
                              
                              ";
            string[] voices_names = {"prima voce", "seconda voce", "terza voce", "quarta voce", "quinta voce"};
            string[] symbols = { "+" };

            Menu.Write(35, 25, logo, Color.Red, 5, voices_names, Color.DarkBlue, "symbolwithname", symbols, Color.GreenYellow, false);
            if (Convert.ToChar(Menu.Choosevoice(Color.Cyan, Color.DarkCyan, String.Empty, false)) == '+')
                Console.Write("bella pe te");
            Thread.Sleep(1500);
            Menu.Clear();
            Console.ReadKey();
        }
        
    }
}
